package br.unigran.view.InterfaceGrafica;

public class MenuPrincipal {

    public static void main(String[] args) {
        new MenuAlternativo().setVisible(true);
    }
}
